from django.apps import AppConfig


class PosConfig(AppConfig):
    name = 'PoS'
