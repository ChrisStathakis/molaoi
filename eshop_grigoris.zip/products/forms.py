from django import forms
from .models import *



class ProductForm(forms.ModelForm):

    class Meta:
        model = Product
        fields ="__all__"









class Supplier_new(forms.ModelForm):


    class Meta:
        model = Supply
        fields = ('title','description','afm','phone','balance')

class CategoryNew(forms.ModelForm):

    class Meta:
        model = Category
        fields = '__all__'



class TaxesForm(forms.ModelForm):

    class Meta:
        model = TaxesCity
        fields = '__all__'




class CreateColor(forms.ModelForm):

    class Meta:
        model = Color
        fields = '__all__'


class CreateSize(forms.ModelForm):

    class Meta:
        model = Size
        fields = '__all__'